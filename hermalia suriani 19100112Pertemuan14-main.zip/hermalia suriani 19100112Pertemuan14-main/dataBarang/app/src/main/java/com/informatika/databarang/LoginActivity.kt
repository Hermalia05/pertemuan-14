package com.informatika.databarang

class LoginActivity {
}